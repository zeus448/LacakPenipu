# Script pelacak penipu — oleh Ubay Boru Sembiring
# Fitur: cek rekening, nomor HP, log, dan kirim ke Telegram

import requests
import time
import json

# ====== KONFIGURASI TELEGRAM (opsional) ======
TELEGRAM_TOKEN = "ISI_TOKEN_BOT_KAMU"
TELEGRAM_CHAT_ID = "ISI_CHAT_ID_KAMU"

def Sembiring(delay):
    time.sleep(delay)

def send_ubay(pesan):  # sebelumnya send_telegram / ptin
    if TELEGRAM_TOKEN == "" or TELEGRAM_CHAT_ID == "":
        return
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    data = {"chat_id": TELEGRAM_CHAT_ID, "text": pesan}
    try:
        requests.post(url, data=data)
    except:
        pass

def log_hasil(label, data):
    with open("log_maling.txt", "a") as f:
        f.write(f"[{label}] {data}\n")

def cek_rekening(norek, bank="BCA"):
    url = "https://cekrekening.id/api/cekrekening"
    headers = {"Content-Type": "application/json"}
    payload = {"bank": bank.upper(), "norek": norek}
    try:
        res = requests.post(url, json=payload, headers=headers)
        hasil = res.json()
        if hasil.get("status") == True:
            pesan = f"⚠️ Rekening terindikasi penipuan: {norek} ({bank})"
            print(pesan)
            log_hasil("REKENING", pesan)
            send_ubay(pesan)
        else:
            print(f"[OK] {norek} ({bank}) aman.")
    except Exception as e:
        print(f"[ERR] Gagal cek rekening: {e}")

def cek_nomor_hp(nomor):
    url = f"https://api.telnyx.com/anonymous/v2/number_lookup/{nomor}"
    try:
        res = requests.get(url)
        hasil = res.json()
        if hasil.get("data"):
            data = hasil["data"]
            pesan = f"📱 Info Nomor: {nomor}\nCarrier: {data.get('carrier')} | Line Type: {data.get('line_type')}"
            print(pesan)
            log_hasil("HP", pesan)
        else:
            print("❌ Gagal cek nomor.")
    except Exception as e:
        print(f"[ERR] Gagal cek nomor: {e}")

def menu():
    print("🔍 LACAK MALING - Ubay Boru Sembiring Edition")
    print("1. Cek Rekening Penipu")
    print("2. Cek Nomor HP")
    print("3. Keluar")
    pilih = input("Pilih menu: ")
    if pilih == "1":
        norek = input("Masukkan No Rekening: ")
        bank = input("Masukkan Nama Bank: ")
        cek_rekening(norek, bank)
        Sembiring(2)
        menu()
    elif pilih == "2":
        nomor = input("Masukkan Nomor HP (62xxxxxxxxxx): ")
        cek_nomor_hp(nomor)
        Sembiring(2)
        menu()
    else:
        print("Selesai. Tetap waspada, Bang!")

if __name__ == "__main__":
    menu()
